import 'package:flutter/material.dart';

class DropdownInput extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _DropdownInputState();
}

class _DropdownInputState extends State<DropdownInput> {
  String dropdownValue = "Apples";
  var dropdownItems = <String>["Apples", "Oranges", "Peaches"];

  @override
  Widget build(BuildContext context) {
    return Container(
      child: DropdownButton(
        value: dropdownValue,
        onChanged: (String value) {
          setState(() {
            dropdownValue = value;
          });
        },
        items: dropdownItems.map((String item) {
          return DropdownMenuItem(
            value: item,
            child: Text(item),
          );
        }).toList(),
      ),
    );
  }
}
