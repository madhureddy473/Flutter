import 'package:flutter/material.dart';

class BasicForm extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _BasicFormState();
}

class _BasicFormState extends State<BasicForm> {
  var formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Form(
              key: formKey,
              child: Column(
                children: [
                  TextFormField(
                    onSaved: (String value) {
                      print("Value: '$value'");
                    },
                  ),
                  TextFormField(
                    onSaved: (String value) {
                      print("Value: '$value'");
                    },
                  ),
                  TextFormField(
                    initialValue: "Hi",
                    onSaved: (String value) {},
                    validator: (String value) {
                      if (value.isEmpty) {
                        return "Provide a value.";
                      }
                      return null;
                    },
                  ),
                ],
              )),
          RaisedButton(
            child: Text("Continue"),
            onPressed: () {
              if (formKey.currentState.validate()) {
                formKey.currentState.save();
              }
            },
          )
        ],
      ),
    );
  }
}
