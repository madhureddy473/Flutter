import 'package:flutter/material.dart';

class RadioInput extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _RadioInputState();
}

class _RadioInputState extends State<RadioInput> {
  String radioValue = "apples";

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          RadioListTile(
            title: Text("Apples"),
            onChanged: (String value) {
              setState(() {
                radioValue = value;
              });
            },
            value: "apples",
            groupValue: radioValue,
          ),
          RadioListTile(
            title: Text("Oranges"),
            onChanged: (String value) {
              setState(() {
                radioValue = value;
              });
            },
            value: "oranges",
            groupValue: radioValue,
          ),
          RadioListTile(
            title: Text("Peaches"),
            onChanged: (String value) {
              setState(() {
                radioValue = value;
              });
            },
            value: "peaces",
            groupValue: radioValue,
          ),
        ],
      ),
    );
  }
}
