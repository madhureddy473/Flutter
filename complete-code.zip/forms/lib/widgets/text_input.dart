import 'package:flutter/material.dart';

class TextInput extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _TextInputState();
}

class _TextInputState extends State<TextInput> {
  final textController = TextEditingController();

  @override
  void initState() {
    super.initState();

    textController.addListener(() {
      print("Current value is ${textController.text}");
    });
  }

  @override
  void dispose() {
    super.dispose();

    if (textController != null) {
      textController.dispose();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: TextField(
        keyboardType: TextInputType.text,
        decoration: InputDecoration(labelText: "Name"),
        maxLength: 50,
        controller: textController,
      ),
    );
  }
}
