import 'package:flutter/material.dart';

class EmailsInput extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _EmailsInput();
}

class _EmailsInput extends State<EmailsInput> {
  bool match = false;
  String email = "";
  String confirmEmail = "";

  void checkEmails() {
    if (this.email.length > 0 &&
        this.confirmEmail.length > 0 &&
        this.email == this.confirmEmail) {
      setState(() {
        match = true;
      });
    } else {
      setState(() {
        match = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          TextField(
            decoration: InputDecoration(labelText: "Email"),
            keyboardType: TextInputType.emailAddress,
            onChanged: (String email) {
              setState(() {
                this.email = email;
              });
              checkEmails();
            },
          ),
          TextField(
            decoration: InputDecoration(labelText: "Confirm Email"),
            keyboardType: TextInputType.emailAddress,
            onChanged: (String email) {
              setState(() {
                this.confirmEmail = email;
              });
              checkEmails();
            },
          ),
          Padding(
            padding: EdgeInsets.all(5),
            child: Text(
              this.match
                  ? "Email addresses match!"
                  : "Email addresses do not match",
              style: TextStyle(fontStyle: FontStyle.italic),
            ),
          ),
          RaisedButton(
            child: Text("Continue"),
            onPressed: this.match
                ? () {
                    Scaffold.of(context).showSnackBar(
                      SnackBar(
                        content: Text("Proceeding..."),
                        action: SnackBarAction(
                          label: "Okay",
                          onPressed: () {},
                        ),
                      ),
                    );
                  }
                : null,
          ),
        ],
      ),
    );
  }
}
